document.write(`125 / 8 = ${125 >>3}`)
document.write("<br/>")
document.write(`40 x 4 = ${40<<2}`)
document.write("<br/>")
document.write(`25 / 2 = ${25>>2}`)
document.write("<br/>")
document.write(`10 x 16 = ${10<<4}`)


