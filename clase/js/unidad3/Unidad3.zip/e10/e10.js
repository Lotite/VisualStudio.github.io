if(!confirm("Tienes hambre?")){
    window.location.assign("error.html")
}
